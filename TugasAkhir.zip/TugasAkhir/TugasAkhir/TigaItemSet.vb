﻿Imports System.Data.SqlClient
Imports System.Data
Module TigaItemSet
    Dim ConStr As String = "Data Source=gidbnd01;Initial Catalog=OPS_PROD;User ID=S-ops_prod;Password=@Bojongso@ng200!;MultipleActiveResultSets=true"
    Dim conn As New SqlClient.SqlConnection(ConStr)
    Private Sub ProcessAssociationRules()

        conn.Open()

        ' Mengambil semua item distinct dari database
        Dim items As List(Of String) = GetDistinctItems(conn)
        ' Menghasilkan semua kombinasi 3-itemset
        Dim itemsets As List(Of String()) = GetCombinations(items, 3)

        ' Menentukan nilai minimum support dan confidence
        Dim minSupport As Double = 0.02 ' Contoh nilai minimum support
        Dim minConfidence As Double = 0.5 ' Contoh nilai minimum confidence

        ' Menjalankan fungsi perhitungan
        CalculateConfidence(minSupport, minConfidence, conn, itemsets)

        conn.Close()

    End Sub

    ' Fungsi untuk menghitung confidence dan menampilkannya di DataGridView
    Private Sub CalculateConfidence(minSupport As Double, minConfidence As Double, conn As SqlConnection, itemsets As List(Of String()))
        Dim totalTransactions As Integer = GetTotalTransactionCount(conn)
        Dim Angka As Integer = 0

        'ProgressBar1.Maximum = itemsets.Count - 1

        ' Bersihkan DataGridView sebelum menampilkan data baru
        ' dgvConfidence.Rows.Clear()

        ' Dim cmdSave As SqlCommand = New SqlCommand("DELETE FROM wms_TA_temp", conn)
        ' cmdSave.ExecuteNonQuery()

        ' Loop melalui setiap 3-itemset
        For i As Integer = 0 To itemsets.Count - 1
            'ProgressBar1.Value = i
            Dim itemset As String() = itemsets(i)

            ' Menghitung support untuk 3-itemset
            Dim supportXYZ As Integer = GetSupportCount(conn, itemset, Nothing)
            Dim support As Double = supportXYZ / totalTransactions

            ' Jika support memenuhi syarat minimum, lanjutkan dengan menghitung confidence
            If support >= minSupport Then
                ' Loop untuk setiap item dalam 3-itemset, mengasumsikan item sebagai consequent
                For j As Integer = 0 To itemset.Length - 1
                    ' Memisahkan antecedent dan consequent
                    Dim antecedent As String() = itemset.Take(j).Concat(itemset.Skip(j + 1)).ToArray()
                    Dim consequent As String() = {itemset(j)}
                    ' Menghitung support untuk antecedent
                    Dim supportX As Integer = GetSupportCount(conn, antecedent, Nothing)

                    ' Menghitung confidence
                    Dim confidence As Double
                    If supportX <> 0 Then
                        confidence = supportXYZ / supportX
                    Else
                        confidence = 0
                    End If

                    ' Memeriksa apakah confidence memenuhi syarat minimum
                    If confidence >= minConfidence Then
                        ' Tambahkan baris ke DataGridView
                        ' dgvConfidence.Rows.Add(GetRuleString(antecedent, consequent), Math.Round(support * 100, 2) & "%", Math.Round(confidence * 100, 2) & "%")

                        ' Simpan hasil ke database
                        Using cmdIns As SqlCommand = New SqlCommand("INSERT INTO wms_TA_temp (rules, supp, conf, lvl) VALUES (@rules, @supp, @conf, @lvl)", conn)
                            cmdIns.Parameters.AddWithValue("@rules", GetRuleString(antecedent, consequent))
                            cmdIns.Parameters.AddWithValue("@supp", Math.Round(support * 100, 5))
                            cmdIns.Parameters.AddWithValue("@conf", Math.Round(confidence * 100, 5))
                            cmdIns.Parameters.AddWithValue("@lvl", "L4")
                            cmdIns.ExecuteNonQuery()
                        End Using
                    End If
                Next
            End If
        Next

        Dim query As String = "SELECT COUNT(*) AS total FROM (SELECT DISTINCT rules AS [Rules], Convert(varchar, CAST(supp AS numeric(9,2))*100) AS [Support], Convert(varchar, CAST(conf AS numeric(9,2))*100) AS [Confidence] FROM wms_TA_temp) A"
        Using cmd As New SqlCommand(query, conn)
            Using reader As SqlDataReader = cmd.ExecuteReader()
                reader.Read()
                Angka = reader("total")
            End Using
        End Using

        ' RichTextBox1.AppendText("Jumlah Data yang diproses [ " & itemsets.Count.ToString() & " Data]" + vbNewLine + "Terbentuk sebanyak [ " & Angka.ToString() & "  Rule Assosiasi]")

        ' DisplayData()
    End Sub

    ' Fungsi untuk mengambil item distinct dari database
    Private Function GetDistinctItems(conn As SqlConnection) As List(Of String)
        Dim items As New List(Of String)
        Dim query As String = "SELECT DISTINCT kd_barang FROM wms_TA WHERE tgl_kirim BETWEEN @tgl1 AND @tgl2"
        Using cmd As New SqlCommand(query, conn)
            cmd.Parameters.AddWithValue("@tgl1", "2022-01-01") 'DateTimePicker1.Value)
            cmd.Parameters.AddWithValue("@tgl2", "2022-12-31") 'DateTimePicker2.Value)
            ' conn.Open()
            Using reader As SqlDataReader = cmd.ExecuteReader()
                While reader.Read()
                    items.Add(reader("kd_barang").ToString())
                End While
            End Using
        End Using
        Return items
    End Function

    ' Fungsi untuk mendapatkan kombinasi itemset
    Private Function GetCombinations(Of T)(items As List(Of T), length As Integer) As List(Of T())
        Dim result As New List(Of T())()
        GetCombinationsRecursive(items.ToArray(), length, New T(length - 1) {}, 0, 0, result)
        Return result
    End Function

    Private Sub GetCombinationsRecursive(Of T)(items As T(), length As Integer, combination As T(), start As Integer, depth As Integer, result As List(Of T()))
        If depth = length Then
            result.Add(DirectCast(combination.Clone(), T()))
            Return
        End If

        For i As Integer = start To items.Length - 1
            combination(depth) = items(i)
            GetCombinationsRecursive(items, length, combination, i + 1, depth + 1, result)
        Next
    End Sub

    ' Fungsi untuk menghitung support count
    Private Function GetSupportCount(conn As SqlConnection, antecedent As Object(), consequent As Object()) As Integer
        Dim count As Integer = 0
        Dim query As New Text.StringBuilder("SELECT COUNT(DISTINCT no_awb) FROM WMS_TA WHERE ")

        If antecedent IsNot Nothing AndAlso antecedent.Length > 0 Then
            query.Append("(")
            For i As Integer = 0 To antecedent.Length - 1
                If i > 0 Then query.Append(" AND ")
                query.Append("no_awb IN (SELECT no_awb FROM WMS_TA WHERE kd_barang = @antecedent" & i & ")")
            Next
            query.Append(")")
        End If

        If consequent IsNot Nothing AndAlso consequent.Length > 0 Then
            If antecedent IsNot Nothing AndAlso antecedent.Length > 0 Then query.Append(" AND ")
            query.Append("(")
            For i As Integer = 0 To consequent.Length - 1
                If i > 0 Then query.Append(" AND ")
                query.Append("no_awb IN (SELECT no_awb FROM WMS_TA WHERE kd_barang = @consequent" & i & ")")
            Next
            query.Append(")")
        End If

        Using cmd As New SqlCommand(query.ToString(), conn)
            ' Menambahkan parameter untuk antecedent
            If antecedent IsNot Nothing Then
                For i As Integer = 0 To antecedent.Length - 1
                    cmd.Parameters.AddWithValue("@antecedent" & i, antecedent(i).ToString())
                Next
            End If

            ' Menambahkan parameter untuk consequent
            If consequent IsNot Nothing Then
                For i As Integer = 0 To consequent.Length - 1
                    cmd.Parameters.AddWithValue("@consequent" & i, consequent(i).ToString())
                Next
            End If

            count = Convert.ToInt32(cmd.ExecuteScalar())
        End Using

        Return count
    End Function

    ' Fungsi untuk mengambil total transaksi
    Private Function GetTotalTransactionCount(conn As SqlConnection) As Integer
        Dim count As Integer
        Dim query As String = "SELECT COUNT(DISTINCT no_awb) FROM wms_TA"
        Using cmd As New SqlCommand(query, conn)
            count = Convert.ToInt32(cmd.ExecuteScalar())
        End Using
        Return count
    End Function

    ' Fungsi untuk membuat string aturan
    Private Function GetRuleString(antecedent As Object(), consequent As Object()) As String
        Return String.Join(", ", antecedent) & " -> " & String.Join(", ", consequent)
    End Function
End Module
