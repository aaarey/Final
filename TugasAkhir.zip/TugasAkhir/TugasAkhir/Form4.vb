﻿Imports System.Data.OleDb
Imports System.Data
Public Class Form4
    Dim ConStr As String = "Provider=Microsoft.ACE.OLEDB.12.0;Data Source=" & Application.StartupPath & "\dataTA.mdb;Persist Security Info=False;Jet OLEDB:Database Password=Azzril@2020"
    Dim conn As New OleDbConnection(ConStr)

    Private Sub CalculateAssociationRules(ByVal startDate As DateTime, ByVal endDate As DateTime, ByVal minSupport As Double, ByVal minConfidence As Double)
        Try
            ' Buka koneksi ke database
            conn.Open()

            Dim cmdDelete As New OleDbCommand("DELETE FROM wms_TA_temp", conn)
            cmdDelete.ExecuteNonQuery()

            ' Query untuk mendapatkan transaksi dari tabel wms_TA berdasarkan tanggal
            Dim query As String = "SELECT no_awb, kd_barang FROM wms_TA WHERE tgl_kirim BETWEEN @tgl1 AND @tgl2 ORDER BY no_awb"
            Dim cmd As New OleDbCommand(query, conn)
            cmd.Parameters.AddWithValue("@tgl1", startDate)
            cmd.Parameters.AddWithValue("@tgl2", endDate)
            Dim reader As OleDbDataReader = cmd.ExecuteReader()


            ' Dictionary untuk menyimpan transaksi berdasarkan no_transaksi
            Dim transactionsDict As New Dictionary(Of String, List(Of String))



            ' Menyimpan hasil query ke dalam transactionsDict
            While reader.Read()
                Dim noTransaksi As String = reader("no_awb").ToString()
                Dim kdBarang As String = reader("kd_barang").ToString()
                ' Jika transaksi sudah ada, tambahkan kd_barang ke transaksi yang sudah ada
                If transactionsDict.ContainsKey(noTransaksi) Then
                    transactionsDict(noTransaksi).Add(kdBarang)
                Else
                    ' Jika transaksi baru, buat entry baru di dictionary
                    transactionsDict(noTransaksi) = New List(Of String) From {kdBarang}
                End If
            End While
            reader.Close()



            ' Mengonversi dictionary transaksi ke dalam List transaksi
            Dim transactions As New List(Of List(Of String))
            For Each transaction In transactionsDict.Values
                transactions.Add(transaction)
            Next

            Dim LTxt As Integer = txtLength.Text

            ' Maksimal panjang itemset
            Dim maxItemsetLength As Integer = LTxt

            ' List untuk menyimpan semua barang unik (distinct)
            Dim itemList As New List(Of String)
            For Each transaction In transactions
                For Each item In transaction
                    If Not itemList.Contains(item) Then
                        itemList.Add(item)
                    End If
                Next
            Next
            ProgressBar1.Value = 0
            ProgressBar1.Maximum = transactions.Count * LTxt - 1


            ' Looping untuk menghitung confidence dan role asosiasi untuk kombinasi barang
            For length As Integer = 2 To maxItemsetLength
                Dim combinations = GetCombinations(itemList, length)


                '    For Each itemset In combinations



                '        ' Memisahkan antecedent dan consequent
                '        Dim antecedent = itemset.Take(length - 1).ToList()
                '        Dim consequent = itemset.Skip(length - 1).Take(1).ToList()

                '        ' Menghitung support untuk antecedent dan seluruh itemset
                '        Dim supportAC = CalculateSupport(itemset, transactions)
                '        Dim supportA = CalculateSupport(antecedent, transactions)


                '        ' Menghitung confidence
                '        Dim confidence As Double = 0
                '        If supportA > 0 Then
                '            confidence = supportAC / supportA
                '        End If



                '        ' Hanya menampilkan jika support dan confidence memenuhi nilai minimum
                '        If supportAC >= minSupport And confidence >= minConfidence Then
                '            ' Membuat string role asosiasi
                '            Dim rule As String = "Jika [" & String.Join(", ", antecedent) & "] maka [" & String.Join(", ", consequent) & "]"

                '            ' Menyimpan role asosiasi dengan support dan confidence ke dalam tabel sementara
                '            Using cmdIns As New OleDbCommand("INSERT INTO wms_TA_temp (rules, supp, conf) VALUES (@rules, @supp, @conf)", conn)
                '                cmdIns.Parameters.AddWithValue("@rules", rule)
                '                cmdIns.Parameters.AddWithValue("@supp", Format(supportAC, "#,##0.000"))
                '                cmdIns.Parameters.AddWithValue("@conf", Format(confidence, "#,##0.000"))
                '                cmdIns.ExecuteNonQuery()
                '            End Using

                '            ProgressBar1.Value += 1
                '        End If
                '    Next
                'Next

                For Each itemset In combinations
                    ' Memisahkan antecedent dan consequent
                    Dim antecedent = itemset.Take(length - 1).ToList()
                    Dim consequent = itemset.Skip(length - 1).Take(1).ToList()

                    ' Menghitung support untuk antecedent, consequent, dan seluruh itemset
                    Dim supportAC = CalculateSupport(itemset, transactions) ' Support(A ∪ B)
                    Dim supportA = CalculateSupport(antecedent, transactions) ' Support(A)
                    Dim supportB = CalculateSupport(consequent, transactions) ' Support(B)

                    ' Menghitung confidence
                    Dim confidence As Double = 0
                    If supportA > 0 Then
                        confidence = supportAC / supportA
                    End If

                    ' Menghitung lift
                    Dim lift As Double = 0
                    If supportA > 0 And supportB > 0 Then
                        lift = supportAC / (supportA * supportB)
                    End If

                    ' Hanya menampilkan jika support, confidence, dan lift memenuhi syarat minimum
                    If supportAC >= minSupport And confidence >= minConfidence Then
                        ' Membuat string role asosiasi
                        Dim rule As String = "Jika [" & String.Join(", ", antecedent) & "] maka [" & String.Join(", ", consequent) & "]"

                        ' Menyimpan role asosiasi dengan support, confidence, dan lift ke dalam tabel sementara
                        Using cmdIns As New OleDbCommand("INSERT INTO wms_TA_temp (rules, supp, conf, lift) VALUES (@rules, @supp, @conf, @lift)", conn)
                            cmdIns.Parameters.AddWithValue("@rules", rule)
                            cmdIns.Parameters.AddWithValue("@supp", Format(supportAC, "#,##0.000"))
                            cmdIns.Parameters.AddWithValue("@conf", Format(confidence, "#,##0.000"))
                            cmdIns.Parameters.AddWithValue("@lift", Format(lift, "#,##0.000"))
                            cmdIns.ExecuteNonQuery()
                        End Using

                        ProgressBar1.Value += 1
                    End If
                Next
            Next

        Catch ex As Exception
            MessageBox.Show("Error: " & ex.Message)
        Finally
            ' Menutup koneksi ke database
            conn.Close()
        End Try
        MsgBox("Finish")
    End Sub

    ' Fungsi untuk menghitung support dari itemset tertentu
    Private Function CalculateSupport(itemset As List(Of String), transactions As List(Of List(Of String))) As Double
        Dim count As Integer = 0
        For Each transaction In transactions
            ' Jika seluruh itemset ada di dalam transaksi
            If itemset.All(Function(item) transaction.Contains(item)) Then
                count += 1
            End If
        Next
        ' Mengembalikan support sebagai proporsi dari total transaksi
        Return count / transactions.Count
    End Function

    ' Fungsi untuk mendapatkan semua kombinasi itemset
    Private Function GetCombinations(items As List(Of String), length As Integer) As List(Of List(Of String))
        Dim result As New List(Of List(Of String))()
        For i As Integer = 0 To items.Count - length
            Dim subset As New List(Of String) From {items(i)}
            If length > 1 Then
                For Each sublist In GetCombinations(items.Skip(i + 1).ToList(), length - 1)
                    result.Add(subset.Concat(sublist).ToList())
                Next
            Else
                result.Add(subset)
            End If
        Next
        Return result
    End Function

    Private Sub IconButton1_Click(sender As Object, e As EventArgs) Handles IconButton1.Click
        'ProcessAssociationRules()
    End Sub

    Private Sub TextBox1_TextChanged(sender As Object, e As EventArgs) Handles TextBox1.TextChanged
        Dim n As Decimal
        n = Val(TextBox1.Text) / 100
        lblsupp.Text = n.ToString
    End Sub

    Private Sub TextBox2_TextChanged(sender As Object, e As EventArgs) Handles TextBox2.TextChanged
        Dim n As Decimal
        n = Val(TextBox2.Text) / 100
        lblconf.Text = n.ToString
    End Sub

    Private Sub IconButton2_Click(sender As Object, e As EventArgs) Handles IconButton2.Click
        Dim startDate As DateTime = Format(DateTimePicker1.Value, "MM/dd/yyyy")
        Dim endDate As DateTime = Format(DateTimePicker2.Value, "MM/dd/yyyy")

        ' Ambil nilai minimum support dan confidence dari input
        Dim minSupport As Double = Convert.ToDouble(lblsupp.Text)
        Dim minConfidence As Double = Convert.ToDouble(lblconf.Text)

        ' Jalankan proses perhitungan role asosiasi
        CalculateAssociationRules(startDate, endDate, minSupport, minConfidence)
    End Sub
End Class