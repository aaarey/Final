﻿Imports System.Data.OleDb
Imports System.Data.SqlClient

Module DBString
    'Public Conn As OleDbConnection
    'Public CMD As OleDbCommand
    'Public Adapter As OleDbDataAdapter
    'Public Data As OleDbDataReader
    'Public DataSet As New DataSet
    Public Sub OpenConnection()
        Dim ConStr1 As String = "Data Source=gidbnd01;Initial Catalog=OPS_PROD;User ID=S-ops_prod;Password=@Bojongso@ng200!;MultipleActiveResultSets=true"
        Dim Conn1 As New SqlClient.SqlConnection(ConStr1)
        'If Conn.State = ConnectionState.Closed Then
        '    Conn.Open()
        'End If
    End Sub

End Module
