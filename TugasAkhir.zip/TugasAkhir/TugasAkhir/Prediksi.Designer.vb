﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Prediksi
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.ComboBox1 = New System.Windows.Forms.ComboBox()
        Me.DataGridView1 = New System.Windows.Forms.DataGridView()
        Me.lbl_n = New System.Windows.Forms.Label()
        Me.lbl_x = New System.Windows.Forms.Label()
        Me.lbl_y = New System.Windows.Forms.Label()
        Me.lbl_xy = New System.Windows.Forms.Label()
        Me.lbl_x2 = New System.Windows.Forms.Label()
        Me.lbl_b = New System.Windows.Forms.Label()
        Me.lbl_a = New System.Windows.Forms.Label()
        Me.lbl_pm = New System.Windows.Forms.Label()
        Me.txt_prediksi = New System.Windows.Forms.TextBox()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.txtnm_brg = New System.Windows.Forms.TextBox()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.txtconf = New System.Windows.Forms.TextBox()
        Me.txtSupp = New System.Windows.Forms.TextBox()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.Label5 = New System.Windows.Forms.Label()
        CType(Me.DataGridView1, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'ComboBox1
        '
        Me.ComboBox1.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.ComboBox1.FormattingEnabled = True
        Me.ComboBox1.Location = New System.Drawing.Point(149, 21)
        Me.ComboBox1.Name = "ComboBox1"
        Me.ComboBox1.Size = New System.Drawing.Size(265, 28)
        Me.ComboBox1.TabIndex = 0
        '
        'DataGridView1
        '
        Me.DataGridView1.AllowUserToAddRows = False
        Me.DataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.DataGridView1.Location = New System.Drawing.Point(420, 21)
        Me.DataGridView1.Name = "DataGridView1"
        Me.DataGridView1.RowHeadersVisible = False
        Me.DataGridView1.Size = New System.Drawing.Size(720, 540)
        Me.DataGridView1.TabIndex = 1
        '
        'lbl_n
        '
        Me.lbl_n.AutoSize = True
        Me.lbl_n.Location = New System.Drawing.Point(26, 216)
        Me.lbl_n.Name = "lbl_n"
        Me.lbl_n.Size = New System.Drawing.Size(13, 13)
        Me.lbl_n.TabIndex = 2
        Me.lbl_n.Text = "n"
        Me.lbl_n.Visible = False
        '
        'lbl_x
        '
        Me.lbl_x.AutoSize = True
        Me.lbl_x.Location = New System.Drawing.Point(26, 245)
        Me.lbl_x.Name = "lbl_x"
        Me.lbl_x.Size = New System.Drawing.Size(12, 13)
        Me.lbl_x.TabIndex = 3
        Me.lbl_x.Text = "x"
        Me.lbl_x.Visible = False
        '
        'lbl_y
        '
        Me.lbl_y.AutoSize = True
        Me.lbl_y.Location = New System.Drawing.Point(26, 276)
        Me.lbl_y.Name = "lbl_y"
        Me.lbl_y.Size = New System.Drawing.Size(12, 13)
        Me.lbl_y.TabIndex = 4
        Me.lbl_y.Text = "y"
        Me.lbl_y.Visible = False
        '
        'lbl_xy
        '
        Me.lbl_xy.AutoSize = True
        Me.lbl_xy.Location = New System.Drawing.Point(26, 312)
        Me.lbl_xy.Name = "lbl_xy"
        Me.lbl_xy.Size = New System.Drawing.Size(17, 13)
        Me.lbl_xy.TabIndex = 5
        Me.lbl_xy.Text = "xy"
        Me.lbl_xy.Visible = False
        '
        'lbl_x2
        '
        Me.lbl_x2.AutoSize = True
        Me.lbl_x2.Location = New System.Drawing.Point(26, 380)
        Me.lbl_x2.Name = "lbl_x2"
        Me.lbl_x2.Size = New System.Drawing.Size(18, 13)
        Me.lbl_x2.TabIndex = 7
        Me.lbl_x2.Text = "x2"
        Me.lbl_x2.Visible = False
        '
        'lbl_b
        '
        Me.lbl_b.AutoSize = True
        Me.lbl_b.Location = New System.Drawing.Point(26, 415)
        Me.lbl_b.Name = "lbl_b"
        Me.lbl_b.Size = New System.Drawing.Size(13, 13)
        Me.lbl_b.TabIndex = 8
        Me.lbl_b.Text = "b"
        Me.lbl_b.Visible = False
        '
        'lbl_a
        '
        Me.lbl_a.AutoSize = True
        Me.lbl_a.Location = New System.Drawing.Point(26, 448)
        Me.lbl_a.Name = "lbl_a"
        Me.lbl_a.Size = New System.Drawing.Size(13, 13)
        Me.lbl_a.TabIndex = 9
        Me.lbl_a.Text = "a"
        Me.lbl_a.Visible = False
        '
        'lbl_pm
        '
        Me.lbl_pm.AutoSize = True
        Me.lbl_pm.Location = New System.Drawing.Point(26, 483)
        Me.lbl_pm.Name = "lbl_pm"
        Me.lbl_pm.Size = New System.Drawing.Size(21, 13)
        Me.lbl_pm.TabIndex = 10
        Me.lbl_pm.Text = "pm"
        Me.lbl_pm.Visible = False
        '
        'txt_prediksi
        '
        Me.txt_prediksi.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txt_prediksi.Location = New System.Drawing.Point(320, 142)
        Me.txt_prediksi.Name = "txt_prediksi"
        Me.txt_prediksi.Size = New System.Drawing.Size(94, 26)
        Me.txt_prediksi.TabIndex = 11
        Me.txt_prediksi.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label1.Location = New System.Drawing.Point(12, 24)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(134, 20)
        Me.Label1.TabIndex = 12
        Me.Label1.Text = "Pilih Kode Barang"
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label2.Location = New System.Drawing.Point(12, 55)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(107, 20)
        Me.Label2.TabIndex = 13
        Me.Label2.Text = "Nama Barang"
        '
        'txtnm_brg
        '
        Me.txtnm_brg.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtnm_brg.Location = New System.Drawing.Point(149, 55)
        Me.txtnm_brg.Name = "txtnm_brg"
        Me.txtnm_brg.Size = New System.Drawing.Size(265, 23)
        Me.txtnm_brg.TabIndex = 14
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label3.Location = New System.Drawing.Point(12, 145)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(103, 20)
        Me.Label3.TabIndex = 15
        Me.Label3.Text = "Data Prediksi"
        '
        'txtconf
        '
        Me.txtconf.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtconf.Location = New System.Drawing.Point(320, 113)
        Me.txtconf.Name = "txtconf"
        Me.txtconf.Size = New System.Drawing.Size(94, 23)
        Me.txtconf.TabIndex = 16
        Me.txtconf.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'txtSupp
        '
        Me.txtSupp.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtSupp.Location = New System.Drawing.Point(320, 84)
        Me.txtSupp.Name = "txtSupp"
        Me.txtSupp.Size = New System.Drawing.Size(94, 23)
        Me.txtSupp.TabIndex = 17
        Me.txtSupp.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label4.Location = New System.Drawing.Point(12, 84)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(99, 20)
        Me.Label4.TabIndex = 18
        Me.Label4.Text = "Nilai Support"
        '
        'Label5
        '
        Me.Label5.AutoSize = True
        Me.Label5.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label5.Location = New System.Drawing.Point(12, 113)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(123, 20)
        Me.Label5.TabIndex = 19
        Me.Label5.Text = "Nilai Confidence"
        '
        'Prediksi
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(1176, 604)
        Me.Controls.Add(Me.Label5)
        Me.Controls.Add(Me.Label4)
        Me.Controls.Add(Me.txtSupp)
        Me.Controls.Add(Me.txtconf)
        Me.Controls.Add(Me.Label3)
        Me.Controls.Add(Me.txtnm_brg)
        Me.Controls.Add(Me.Label2)
        Me.Controls.Add(Me.Label1)
        Me.Controls.Add(Me.txt_prediksi)
        Me.Controls.Add(Me.lbl_pm)
        Me.Controls.Add(Me.lbl_a)
        Me.Controls.Add(Me.lbl_b)
        Me.Controls.Add(Me.lbl_x2)
        Me.Controls.Add(Me.lbl_xy)
        Me.Controls.Add(Me.lbl_y)
        Me.Controls.Add(Me.lbl_x)
        Me.Controls.Add(Me.lbl_n)
        Me.Controls.Add(Me.DataGridView1)
        Me.Controls.Add(Me.ComboBox1)
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None
        Me.Name = "Prediksi"
        Me.Text = "Prediksi"
        CType(Me.DataGridView1, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents ComboBox1 As ComboBox
    Friend WithEvents DataGridView1 As DataGridView
    Friend WithEvents lbl_n As Label
    Friend WithEvents lbl_x As Label
    Friend WithEvents lbl_y As Label
    Friend WithEvents lbl_xy As Label
    Friend WithEvents lbl_x2 As Label
    Friend WithEvents lbl_b As Label
    Friend WithEvents lbl_a As Label
    Friend WithEvents lbl_pm As Label
    Friend WithEvents txt_prediksi As TextBox
    Friend WithEvents Label1 As Label
    Friend WithEvents Label2 As Label
    Friend WithEvents txtnm_brg As TextBox
    Friend WithEvents Label3 As Label
    Friend WithEvents txtconf As TextBox
    Friend WithEvents txtSupp As TextBox
    Friend WithEvents Label4 As Label
    Friend WithEvents Label5 As Label
End Class
