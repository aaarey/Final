﻿Imports System.Data.OleDb
Imports System.Data
Public Class Form5
    Dim ConStr As String = "Provider=Microsoft.ACE.OLEDB.12.0;Data Source=" & Application.StartupPath & "\dataTA.mdb;Persist Security Info=False;Jet OLEDB:Database Password=Azzril@2020"
    Dim conn As New OleDbConnection(ConStr)

    ' Function untuk menghitung support
    Public Function HitungSupport(itemsetTransaksi As Integer, totalTransaksi As Integer) As Double
        If totalTransaksi = 0 Then
            Return 0
        End If
        Dim support As Double = (itemsetTransaksi / totalTransaksi) * 100
        Return support
    End Function

    ' Function untuk mengambil total transaksi dari database berdasarkan tanggal pengiriman
    Public Function GetTotalTransaksi(tgl1 As Date, tgl2 As Date) As Integer
        Dim totalTransaksi As Integer = 0
        Try
            Dim query As String = "SELECT COUNT(no_awb) From (Select distinct no_awb FROM wms_TA WHERE tgl_kirim BETWEEN @tgl1 AND @tgl2)"
            Dim cmd As New OleDbCommand(query, conn)
            cmd.Parameters.AddWithValue("@tgl1", tgl1)
            cmd.Parameters.AddWithValue("@tgl2", tgl2)

            conn.Open()
            totalTransaksi = Convert.ToInt32(cmd.ExecuteScalar())
        Catch ex As Exception
            'MessageBox.Show(ex.Message)
        Finally
            conn.Close()
        End Try
        Return totalTransaksi
    End Function

    ' Function untuk mengambil itemset dari database
    Public Function GetItemsetFromDB(tgl1 As Date, tgl2 As Date) As List(Of String())
        Dim itemsetList As New List(Of String())()

        Try
            ' Query untuk mengambil item kd_barang berdasarkan no_awb
            Dim query As String = "SELECT no_awb, kd_barang FROM wms_TA WHERE tgl_kirim BETWEEN @tgl1 AND @tgl2 ORDER BY no_awb"
            Dim cmd As New OleDbCommand(query, conn)
            cmd.Parameters.AddWithValue("@tgl1", tgl1)
            cmd.Parameters.AddWithValue("@tgl2", tgl2)

            conn.Open()
            Dim reader As OleDbDataReader = cmd.ExecuteReader()

            ' Menggabungkan itemset per transaksi (no_awb)
            Dim currentAwb As String = ""
            Dim itemset As New List(Of String)
            While reader.Read()
                Dim awb As String = reader("no_awb").ToString()
                Dim kd_barang As String = reader("kd_barang").ToString()

                If awb <> currentAwb Then
                    ' Jika awb berubah, tambahkan itemset sebelumnya ke dalam daftar
                    If itemset.Count > 0 Then
                        itemsetList.Add(itemset.ToArray())
                    End If
                    ' Reset itemset dan perbarui currentAwb
                    itemset = New List(Of String)
                    currentAwb = awb
                End If

                ' Tambahkan kd_barang ke itemset
                itemset.Add(kd_barang)
            End While

            ' Tambahkan itemset terakhir
            If itemset.Count > 0 Then
                itemsetList.Add(itemset.ToArray())
            End If

        Catch ex As Exception
            ' MessageBox.Show(ex.Message)
        Finally
            conn.Close()
        End Try

        Return itemsetList
    End Function

    ' Function untuk mengambil jumlah transaksi yang mengandung itemset tertentu berdasarkan tanggal pengiriman
    Public Function GetItemsetTransaksi(itemset As String(), tgl1 As Date, tgl2 As Date) As Integer
        Dim itemsetTransaksi As Integer = 0
        Try
            ' Buat query SQL untuk menghitung transaksi yang mengandung itemset
            Dim query As String = "SELECT COUNT(no_awb) From (Select distinct no_awb FROM wms_TA WHERE tgl_kirim BETWEEN @tgl1 AND @tgl2)"

            For i As Integer = 0 To itemset.Length - 1
                If i > 0 Then
                    query &= " AND no_awb IN (SELECT no_awb FROM wms_TA WHERE kd_barang = '" & itemset(i) & "')"
                Else
                    query &= " AND kd_barang = '" & itemset(i) & "'"
                End If
            Next

            Dim cmd As New OleDbCommand(query, conn)
            cmd.Parameters.AddWithValue("@tgl1", tgl1)
            cmd.Parameters.AddWithValue("@tgl2", tgl2)

            conn.Open()
            itemsetTransaksi = Convert.ToInt32(cmd.ExecuteScalar())
        Catch ex As Exception
            'MessageBox.Show(ex.Message)
        Finally
            conn.Close()
        End Try
        Return itemsetTransaksi
    End Function

    ' Function untuk mengisi DataGridView
    Public Sub TampilkanKeDataGridView(itemsetList As List(Of String()), tgl1 As Date, tgl2 As Date, totalTransaksi As Integer)
        ' Buat kolom untuk DataGridView jika belum ada
        If DataGridView1.Columns.Count = 0 Then
            DataGridView1.Columns.Add("Itemset", "Itemset")
            DataGridView1.Columns.Add("Support", "Support (%)")
        End If

        ' Bersihkan DataGridView
        DataGridView1.Rows.Clear()

        ' Hitung support untuk setiap itemset dan tampilkan di DataGridView
        For Each itemset As String() In itemsetList
            Dim transaksiItemset As Integer = GetItemsetTransaksi(itemset, tgl1, tgl2)
            Dim supportItemset As Double = HitungSupport(transaksiItemset, totalTransaksi)

            ' Tambahkan baris ke DataGridView
            DataGridView1.Rows.Add(String.Join(", ", itemset), supportItemset.ToString("F2"))
        Next
    End Sub


    Private Sub IconButton1_Click(sender As Object, e As EventArgs) Handles IconButton1.Click
        ' Tentukan tanggal mulai dan tanggal akhir
        Dim tgl1 As Date = New Date(2022, 1, 1) ' Ganti dengan tanggal mulai
        Dim tgl2 As Date = New Date(2022, 12, 31) ' Ganti dengan tanggal akhir

        ' Ambil total transaksi berdasarkan rentang tanggal
        Dim totalTransaksi As Integer = GetTotalTransaksi(tgl1, tgl2)

        ' Ambil itemset dari database berdasarkan rentang tanggal
        Dim itemsetList As List(Of String()) = GetItemsetFromDB(tgl1, tgl2)

        ' Tampilkan hasil perhitungan support di DataGridView
        TampilkanKeDataGridView(itemsetList, tgl1, tgl2, totalTransaksi)
    End Sub
End Class