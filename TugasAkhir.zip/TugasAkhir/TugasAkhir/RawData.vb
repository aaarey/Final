﻿Imports System.Data
Imports System.Data.OleDb
Public Class RawData
    Dim ConStr As String = "Provider=Microsoft.ACE.OLEDB.12.0;Data Source=" & Application.StartupPath & "\dataTA.mdb;Persist Security Info=False;Jet OLEDB:Database Password=Azzril@2020"
    Dim conn As New OleDbConnection(ConStr)
    Private Sub RawData_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        InitializeDataGridView()
        DisplayData()
    End Sub
    Private Sub InitializeDataGridView()
        ' Menambahkan kolom ke DataGridView
        With DataGridView1
            .Columns.Clear()
            .Columns.Add("No", "No")
            .Columns.Add("No Pengiriman", "No Pengiriman")
            .Columns.Add("No Faktur", "No Faktur")
            .Columns.Add("Tgl Kirim", "Tgl Kirim")
            .Columns.Add("Kode Barang", "Kode Barang")
            .Columns.Add("Nama Barang", "Nama Barang")
            .Columns.Add("Batch", "Batch")
            .Columns.Add("Jumlah Kirim", "Jumlah Kirim")
            .Columns(0).HeaderCell.Style.Alignment = DataGridViewContentAlignment.MiddleCenter
            .Columns(1).HeaderCell.Style.Alignment = DataGridViewContentAlignment.MiddleCenter
            .Columns(2).HeaderCell.Style.Alignment = DataGridViewContentAlignment.MiddleCenter
            .Columns(3).HeaderCell.Style.Alignment = DataGridViewContentAlignment.MiddleCenter
            .Columns(4).HeaderCell.Style.Alignment = DataGridViewContentAlignment.MiddleCenter
            .Columns(5).HeaderCell.Style.Alignment = DataGridViewContentAlignment.MiddleCenter
            .Columns(6).HeaderCell.Style.Alignment = DataGridViewContentAlignment.MiddleCenter
            .Columns(7).HeaderCell.Style.Alignment = DataGridViewContentAlignment.MiddleCenter
            .Columns(0).Width = 50
            .Columns(1).Width = 100
            .Columns(2).Width = 100
            .Columns(3).Width = 100
            .Columns(4).Width = 150
            .Columns(5).Width = 320
            .Columns(6).Width = 100
            .Columns(7).Width = 50
        End With
    End Sub

    Sub DisplayData()
        conn.Open()
        Using cmd As New OleDbCommand("SELECT no_awb as [No Pengiriman], no_inv as [No Faktur], 
                                               tgl_kirim as [Tgl Kirim], kd_barang as [Kode Barang], nm_barang as [Nama Barang], no_batch as [Batch], jml as [Jumlah Kirim] FROM wms_TA", conn)
            Using sda As New OleDbDataAdapter(cmd)
                Using dt As New DataTable()
                    sda.Fill(dt)
                    DataGridView1.Columns.Clear()
                    DataGridView1.Columns.Add("No", "No")
                    DataGridView1.DataSource = dt
                    For i As Integer = 0 To DataGridView1.Rows.Count - 1
                        DataGridView1.Rows(i).Cells("No").Value = i + 1 ' Mengisi nomor urut dimulai dari 1
                    Next
                    With DataGridView1
                        .DefaultCellStyle.Font = New Font("Tahoma", 11)
                        .DataSource = dt
                        .Columns(0).HeaderCell.Style.Alignment = DataGridViewContentAlignment.MiddleCenter
                        .Columns(1).HeaderCell.Style.Alignment = DataGridViewContentAlignment.MiddleCenter
                        .Columns(2).HeaderCell.Style.Alignment = DataGridViewContentAlignment.MiddleCenter
                        .Columns(3).HeaderCell.Style.Alignment = DataGridViewContentAlignment.MiddleCenter
                        .Columns(4).HeaderCell.Style.Alignment = DataGridViewContentAlignment.MiddleCenter
                        .Columns(5).HeaderCell.Style.Alignment = DataGridViewContentAlignment.MiddleCenter
                        .Columns(6).HeaderCell.Style.Alignment = DataGridViewContentAlignment.MiddleCenter
                        .Columns(6).HeaderCell.Style.Alignment = DataGridViewContentAlignment.MiddleCenter

                        .Columns(0).DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleRight
                        .Columns(1).DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleRight
                        .Columns(2).DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleRight
                        .Columns(3).DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleRight
                        .Columns(4).DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleLeft
                        .Columns(5).DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleLeft
                        .Columns(6).DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleRight
                        .Columns(7).DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleRight

                        .Columns(0).Width = 50
                        .Columns(1).Width = 100
                        .Columns(2).Width = 100
                        .Columns(3).Width = 100
                        .Columns(4).Width = 150
                        .Columns(5).Width = 320
                        .Columns(6).Width = 100
                        .Columns(7).Width = 50

                    End With
                End Using
            End Using
        End Using

        Dim sqla As String = "SELECT count(*) as [total]  From wms_TA"
        Dim cmda As New OleDbCommand(sqla, conn)
        Using sdra As OleDbDataReader = cmda.ExecuteReader
            sdra.Read()
            TextBox1.Text = Format(Val(sdra("total")), "###,###")
        End Using

        Dim sql As String = "SELECT count(no_awb) as [total] From (Select distinct no_awb  From wms_TA) A"
        Dim cmd2 As New OleDbCommand(sql, conn)
        Using sdr As OleDbDataReader = cmd2.ExecuteReader
            sdr.Read()
            TextBox2.Text = Format(Val(sdr("total")), "###,###")
        End Using


        conn.Close()
    End Sub
End Class