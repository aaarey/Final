﻿Imports System.Data.SqlClient
Imports System.Data


Public Class Prediksi
    Dim ConStr As String = "Data Source=gidbnd01;Initial Catalog=OPS_PROD;User ID=S-ops_prod;Password=@Bojongso@ng200!;MultipleActiveResultSets=true"
    Dim conn As New SqlClient.SqlConnection(ConStr)
    Private Sub Prediksi_Load(sender As Object, e As EventArgs) Handles MyBase.Load

        conn.Open()
        Dim sqla As String = "SELECT Distinct kd_barang  From wms_TA order by kd_barang asc"
        Dim cmda As New SqlClient.SqlCommand(sqla, conn)
        Using sdra As SqlClient.SqlDataReader = cmda.ExecuteReader()
            If sdra.HasRows Then
                ComboBox1.Items.Clear()
                While sdra.Read()
                    ComboBox1.Items.Add(sdra("kd_barang").ToString)
                End While
            End If
        End Using
        conn.Close()
    End Sub

    Sub prediksi()
        conn.Open()

        Using cmd As New SqlClient.SqlCommand("select Bulan, thn as 'Tahun', kd_barang as 'Kode Barang', nm_barang as 'Nama Barang', X, Y,  sum(Y*X) as 'XY', sum(X*X) as 'X2' from " &
            "(select Bulan, thn, kd_barang, nm_barang, sum(jml) as 'Y', ROW_NUMBER() OVER (ORDER BY thn)-1  as 'X' from " &
            "(SELECT Format(tgl_kirim, 'MM') as Bulan, year(tgl_kirim) as thn, kd_barang, nm_barang, jml from wms_TA ) B " &
            "where kd_barang =@part " &
            "group by bulan, thn, kd_barang, nm_barang) C " &
            "group by bulan, thn, kd_barang, nm_barang, Y, X  " &
            "order by convert(varchar,thn,110), convert(varchar,bulan,110) asc", conn)
            cmd.CommandType = CommandType.Text
            cmd.Parameters.AddWithValue("@part", ComboBox1.Text)

            Using sda As New SqlClient.SqlDataAdapter(cmd)
                Using dt As New DataTable()
                    sda.Fill(dt)
                    With DataGridView1
                        .DataSource = dt
                        .Columns(0).HeaderCell.Style.Alignment = DataGridViewContentAlignment.MiddleCenter
                        .Columns(1).HeaderCell.Style.Alignment = DataGridViewContentAlignment.MiddleCenter
                        .Columns(2).HeaderCell.Style.Alignment = DataGridViewContentAlignment.MiddleCenter
                        .Columns(3).HeaderCell.Style.Alignment = DataGridViewContentAlignment.MiddleCenter
                        .Columns(4).HeaderCell.Style.Alignment = DataGridViewContentAlignment.MiddleCenter
                        .Columns(5).HeaderCell.Style.Alignment = DataGridViewContentAlignment.MiddleCenter
                        .Columns(6).HeaderCell.Style.Alignment = DataGridViewContentAlignment.MiddleCenter
                        .Columns(7).HeaderCell.Style.Alignment = DataGridViewContentAlignment.MiddleCenter
                        .Columns(0).DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleRight
                        .Columns(1).DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleRight
                        .Columns(2).DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleLeft
                        .Columns(3).DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleLeft
                        .Columns(4).DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleRight
                        .Columns(5).DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleRight
                        .Columns(6).DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleRight
                        .Columns(7).DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleRight
                        .Columns(0).Width = 50
                        .Columns(1).Width = 50
                        .Columns(2).Width = 150
                        .Columns(3).Width = 250
                        .Columns(4).Width = 50
                        .Columns(5).Width = 50
                        .Columns(6).Width = 50
                        .Columns(7).Width = 50
                    End With
                End Using
            End Using
        End Using


        Using cmd As New SqlClient.SqlCommand("select count(*) as total From (select Bulan, thn as 'Tahun', kd_barang as 'Kode Barang', nm_barang as 'Nama Barang', X, Y,  sum(Y*X) as 'XY', sum(X*X) as 'X2' from " &
            "(select Bulan, thn, kd_barang, nm_barang, sum(jml) as 'Y', ROW_NUMBER() OVER (ORDER BY thn)-1  as 'X' from " &
            "(SELECT Format(tgl_kirim, 'MM') as Bulan, year(tgl_kirim) as thn, kd_barang, nm_barang, jml from wms_TA ) B " &
            "where kd_barang =@part " &
            "group by bulan, thn, kd_barang, nm_barang) C " &
            "group by bulan, thn, kd_barang, nm_barang, Y, X) E", conn)
            cmd.CommandType = CommandType.Text
            cmd.Parameters.AddWithValue("@part", ComboBox1.Text)

            Using sdra As SqlClient.SqlDataReader = cmd.ExecuteReader()
                sdra.Read()
                lbl_n.Text = sdra("total").ToString
            End Using

        End Using


        Using cmd As New SqlClient.SqlCommand("select SUM(x) as X1, SUM(Y) as Y1, SUM(YX) as YX1, SUM(X2) as X21 From " &
           "(select Bulan, thn as 'Tahun', kd_barang as 'Kode Barang', nm_barang as 'Nama Barang', X, Y,  sum(Y*X) as 'YX', sum(X*X) as 'X2' from " &
           "(select Bulan, thn, kd_barang, nm_barang, sum(jml) as 'Y', ROW_NUMBER() OVER (ORDER BY thn)-1  as 'X' from " &
           "(SELECT Format(tgl_kirim, 'MM') as Bulan, year(tgl_kirim) as thn, kd_barang, nm_barang, jml from wms_TA ) B " &
           "where kd_barang =@part " &
           "group by bulan, thn, kd_barang, nm_barang) C " &
           "group by bulan, thn, kd_barang, nm_barang, Y, X) D", conn)
            cmd.CommandType = CommandType.Text
            cmd.Parameters.AddWithValue("@part", ComboBox1.Text)
            Using sdra As SqlClient.SqlDataReader = cmd.ExecuteReader()
                sdra.Read()
                lbl_x.Text = sdra("X1").ToString
                lbl_y.Text = sdra("Y1").ToString
                lbl_xy.Text = sdra("YX1").ToString
                lbl_x2.Text = sdra("X21").ToString

            End Using
        End Using

        conn.Close()

        Dim b As Double = ((Val(lbl_n.Text) * Val(lbl_xy.Text)) - (Val(lbl_x.Text) * Val(lbl_y.Text))) / ((Val(lbl_n.Text) * Val(lbl_x2.Text)) - (Val(lbl_x.Text) * Val(lbl_x.Text)))
        lbl_b.Text = Math.Round(b, 3).ToString

        Dim a As Double = (Val(lbl_y.Text) - (Val(lbl_b.Text) * Val(lbl_x.Text))) / Val(lbl_n.Text)
        lbl_a.Text = Math.Round(a, 3).ToString

        Dim pm As Double = Val(lbl_a.Text) + (Val(lbl_b.Text) * Val(lbl_n.Text) + 2)
        lbl_pm.Text = Math.Round(pm, 3).ToString

        txt_prediksi.Text = Math.Round(pm, 0).ToString


    End Sub
    Sub CekBrg()
        conn.Open()
        Dim sqla As String = "SELECT nm_barang From wms_TA where kd_barang=@kdbrg"
        Dim cmda As New SqlClient.SqlCommand(sqla, conn)
        cmda.Parameters.AddWithValue("@kdbrg", ComboBox1.Text)
        Using sdra As SqlDataReader = cmda.ExecuteReader()
            sdra.Read()
            txtnm_brg.Text = sdra("nm_barang").ToString
        End Using
        conn.Close()
    End Sub
    Private Sub ComboBox1_SelectedValueChanged(sender As Object, e As EventArgs) Handles ComboBox1.SelectedValueChanged
        prediksi()
        CekBrg()
        CalculateConfidence(ComboBox1.Text, ConStr)

    End Sub

    Private Sub ComboBox1_TextChanged(sender As Object, e As EventArgs) Handles ComboBox1.TextChanged
        prediksi()
        CekBrg()
        Dim hasil As Double = Math.Round(CalculateConfidence(ComboBox1.Text, ConStr), 2)
        txtconf.Text = hasil.ToString & "%"

        Dim support As Double = Math.Round(CalculateSupport(ComboBox1.Text, ConStr), 2)
        txtSupp.Text = support.ToString & "%"
    End Sub

    Public Function CalculateConfidence(partNumber As String, connectionString As String) As Double
        Dim totalTransactions As Integer
        Dim partNumberTransactions As Integer
        Dim confidence As Double

        Using connection As New SqlConnection(connectionString)
            connection.Open()

            ' Calculate total number of transactions
            Dim totalTransactionsCmd As New SqlCommand("SELECT COUNT(no_awb) FROM wms_TA WHERE kd_barang = @PartNumber", connection)
            totalTransactionsCmd.Parameters.AddWithValue("@PartNumber", ComboBox1.Text)
            totalTransactions = Convert.ToInt32(totalTransactionsCmd.ExecuteScalar())

            ' Calculate the number of transactions that contain the part number
            Dim partNumberTransactionsCmd As New SqlCommand("SELECT COUNT(DISTINCT no_awb) FROM wms_TA WHERE kd_barang = @PartNumber", connection)
            partNumberTransactionsCmd.Parameters.AddWithValue("@PartNumber", ComboBox1.Text)
            partNumberTransactions = Convert.ToInt32(partNumberTransactionsCmd.ExecuteScalar())

        End Using
        ' Calculate confidence
        If totalTransactions > 0 Then
            confidence = partNumberTransactions / totalTransactions * 100
        Else
            confidence = 0
        End If

        Return confidence
    End Function

    Private Function CalculateSupport(partNumber As String, connectionString As String) As Double
        Dim totalTransactions As Integer
        Dim partNumberTransactions As Integer
        Dim support As Double

        ' Create and open the SQL connection
        Using connection As New SqlConnection(connectionString)
            connection.Open()

            ' Calculate total number of transactions
            Dim totalTransactionsCmd As New SqlCommand("SELECT COUNT(DISTINCT no_awb) FROM wms_TA", connection)

            totalTransactions = Convert.ToInt32(totalTransactionsCmd.ExecuteScalar())

            ' Calculate the number of transactions that contain the part number
            Dim partNumberTransactionsCmd As New SqlCommand("SELECT COUNT(DISTINCT no_awb) FROM wms_TA WHERE kd_barang = @PartNumber", connection)
            partNumberTransactionsCmd.Parameters.AddWithValue("@PartNumber", ComboBox1.Text)
            partNumberTransactions = Convert.ToInt32(partNumberTransactionsCmd.ExecuteScalar())
        End Using

        ' Calculate support
        If totalTransactions > 0 Then
            support = partNumberTransactions / totalTransactions * 100
        Else
            support = 0
        End If

        Return support
    End Function
End Class
