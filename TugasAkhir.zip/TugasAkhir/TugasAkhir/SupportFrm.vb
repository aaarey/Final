﻿Imports System.IO
Imports System.Data.OleDb
Imports Excel = Microsoft.Office.Interop.Excel
Public Class SupportFrm

    Dim ConStr As String = "Provider=Microsoft.ACE.OLEDB.12.0;Data Source=" & Application.StartupPath & "\dataTA.mdb;Persist Security Info=False;Jet OLEDB:Database Password=Azzril@2020"
    Dim conn As New OleDbConnection(ConStr)
    Sub InitializeDataGridView()
        ' Menambahkan kolom ke DataGridView
        With DataGridView1
            .Columns.Clear()
            .Columns.Add("No", "No")
            .Columns.Add("Kode Barang", "Kode Barang")
            .Columns.Add("Nama Barang", "Nama Barang")
            .Columns.Add("Jumlah", "Jumlah")
            .Columns.Add("Support", "Support")
            .Columns(0).HeaderCell.Style.Alignment = DataGridViewContentAlignment.MiddleCenter
            .Columns(1).HeaderCell.Style.Alignment = DataGridViewContentAlignment.MiddleCenter
            .Columns(2).HeaderCell.Style.Alignment = DataGridViewContentAlignment.MiddleCenter
            .Columns(3).HeaderCell.Style.Alignment = DataGridViewContentAlignment.MiddleCenter
            .Columns(4).HeaderCell.Style.Alignment = DataGridViewContentAlignment.MiddleCenter
            .Columns(0).Width = 50
            .Columns(1).Width = 250
            .Columns(2).Width = 400
            .Columns(3).Width = 100
            .Columns(4).Width = 100
        End With
    End Sub
    Private Sub SupportFrm_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        InitializeDataGridView()
    End Sub

    Sub DisplayData()
        conn.Open()

        Using cmd As New OleDbCommand("SELECT[Kode Barang], [Nama Barang],  Jumlah, [Support (%)]   FROM
                                                (
                                                SELECT 
                                                    kd_barang AS [Kode Barang], 
                                                    nm_barang AS [Nama Barang], 
                                                    FORMAT(SUM(jml), '#,0') AS Jumlah,
                                                    SUM(jml) / (SELECT COUNT(*) FROM wms_TA) AS [Support],
                                                    FormatPercent(SUM(jml) / (SELECT COUNT(*) FROM wms_TA)) AS [Support (%)]
                                                FROM 
                                                    wms_TA
                                                GROUP BY 
                                                    kd_barang, nm_barang
                                                )
                                                Order By Support Desc", conn)

            Using sda As New OleDbDataAdapter(cmd)
                Using dt As New DataTable()
                    sda.Fill(dt)

                    ' Isi nomor urut
                    DataGridView1.Columns.Clear()
                    DataGridView1.Columns.Add("No", "No")
                    DataGridView1.DataSource = dt
                    For i As Integer = 0 To DataGridView1.Rows.Count - 1
                        DataGridView1.Rows(i).Cells("No").Value = i + 1 ' Mengisi nomor urut dimulai dari 1
                    Next

                    With DataGridView1
                        .DefaultCellStyle.Font = New Font("Tahoma", 12)
                        .Columns(0).HeaderCell.Style.Alignment = DataGridViewContentAlignment.MiddleCenter
                        .Columns(1).HeaderCell.Style.Alignment = DataGridViewContentAlignment.MiddleCenter
                        .Columns(2).HeaderCell.Style.Alignment = DataGridViewContentAlignment.MiddleCenter
                        .Columns(3).HeaderCell.Style.Alignment = DataGridViewContentAlignment.MiddleCenter
                        .Columns(4).HeaderCell.Style.Alignment = DataGridViewContentAlignment.MiddleCenter

                        .Columns(0).DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleRight
                        .Columns(1).DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleLeft
                        .Columns(2).DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleLeft
                        .Columns(3).DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleRight
                        .Columns(4).DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleRight

                        .Columns(0).Width = 50
                        .Columns(1).Width = 250
                        .Columns(2).Width = 400
                        .Columns(3).Width = 100
                        .Columns(4).Width = 100

                    End With
                End Using
            End Using
        End Using

        conn.Close()
    End Sub
    Private Sub releaseObject(ByVal obj As Object)
        Try
            System.Runtime.InteropServices.Marshal.ReleaseComObject(obj)
            obj = Nothing
        Catch ex As Exception
            obj = Nothing
        Finally
            GC.Collect()
        End Try
    End Sub

    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        Dim exePath As String = Application.StartupPath()
        Dim xlApp As Excel.Application
        Dim xlWorkBook As Excel.Workbook
        Dim xlWorkSheet As Excel.Worksheet
        Dim misValue As Object = System.Reflection.Missing.Value
        Dim i As Integer
        Dim j As Integer

        xlApp = New Excel.Application
        xlWorkBook = xlApp.Workbooks.Add(misValue)
        xlWorkSheet = xlWorkBook.Sheets("sheet1")
        Button1.Enabled = False
        ProgressBar1.Maximum = DataGridView1.RowCount

        For k = 0 To DataGridView1.ColumnCount - 1
            xlWorkSheet.Cells(1, k + 1).HorizontalAlignment = Microsoft.Office.Interop.Excel.XlHAlign.xlHAlignCenter
            xlWorkSheet.Cells(1, k + 1) = DataGridView1.Columns(k).Name
        Next

        Dim X As Integer = 0
        For i = 0 To DataGridView1.RowCount - 1
            For j = 0 To DataGridView1.ColumnCount - 1
                xlWorkSheet.Cells(i + 2, j + 1).HorizontalAlignment = Microsoft.Office.Interop.Excel.XlHAlign.xlHAlignCenter
                xlWorkSheet.Cells(i + 2, j + 1) =
                DataGridView1(j, i).Value.ToString()
            Next
            X = X + 1
            ProgressBar1.Value = X
        Next

        xlApp.DisplayAlerts = False
        xlApp.Visible = True
        Button1.Enabled = True
        releaseObject(xlApp)
        releaseObject(xlWorkBook)
        releaseObject(xlWorkSheet)
    End Sub

    Private Sub IconButton1_Click(sender As Object, e As EventArgs) Handles IconButton1.Click
        DisplayData()
    End Sub

    Private Sub SupportFrm_Leave(sender As Object, e As EventArgs) Handles MyBase.Leave
        InitializeDataGridView()
    End Sub
End Class