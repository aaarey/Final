﻿
Public Class Form1
    Private currentBtn As Button
    Private leftBorderBtn As Panel
    Public Sub New()

        ' This call is required by the designer.
        InitializeComponent()

        ' Add any initialization after the InitializeComponent() call.
        leftBorderBtn = New Panel
        leftBorderBtn.Size = New Size(7, 50)
        PanelSide.Controls.Add(leftBorderBtn)
    End Sub
    Private Sub ActiveButton(senderBtn As Object, customColor As Color)
        If senderBtn IsNot Nothing Then
            DisableBtn()
            currentBtn = CType(senderBtn, Button)
            currentBtn.BackColor = Color.DarkGray
            currentBtn.ForeColor = Color.Transparent

            leftBorderBtn.BackColor = customColor
            leftBorderBtn.Location = New Point(0, currentBtn.Location.Y)
            leftBorderBtn.Visible = True
            leftBorderBtn.BringToFront()
            currentBtn.TextImageRelation = TextImageRelation.TextBeforeImage

        End If
    End Sub
    Private Sub DisableBtn()
        If currentBtn IsNot Nothing Then
            currentBtn.BackColor = Color.Transparent
            currentBtn.ForeColor = Color.White
            currentBtn.TextImageRelation = TextImageRelation.ImageBeforeText

        End If
    End Sub

    Private Sub AddForm(frm As Form)
        PanelContainer.Controls.Clear()
        frm.TopLevel = False
        frm.TopMost = True
        frm.Dock = DockStyle.Fill
        PanelContainer.Controls.Add(frm)
        frm.Show()
    End Sub

    Private Sub Change_Menu(menu As String)
        Select Case menu
            Case "Home"
                AddForm(RawData)
            Case "Support"
                AddForm(SupportFrm)
            Case "Confidence"
                AddForm(ConfidenceFrm)
            Case "Analisa"
                AddForm(Form4)
            Case "ViewSupp"
                AddForm(Form5)
        End Select
    End Sub


    Private Sub IconButton1_Click(sender As Object, e As EventArgs) Handles IconButton1.Click
        ActiveButton(sender, Color.Crimson)
        Change_Menu("Home")
        RawData.DisplayData()
    End Sub

    Private Sub IconButton2_Click(sender As Object, e As EventArgs) Handles IconButton2.Click
        ActiveButton(sender, Color.Crimson)
        Change_Menu("Analisa")
    End Sub

    Private Sub IconButton3_Click(sender As Object, e As EventArgs) Handles IconButton3.Click

        ActiveButton(sender, Color.Crimson)
        Change_Menu("Support")

    End Sub

    Private Sub IconButton4_Click(sender As Object, e As EventArgs) Handles IconButton4.Click

        ActiveButton(sender, Color.Crimson)
        Change_Menu("Confidence")

    End Sub

    Private Sub IconButton5_Click(sender As Object, e As EventArgs) 

    End Sub
End Class
